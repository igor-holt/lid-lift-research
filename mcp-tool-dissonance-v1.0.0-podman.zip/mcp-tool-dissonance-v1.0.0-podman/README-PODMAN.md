# MCP Tool Dissonance v1.0.0 - Podman Edition

**DOI:** [10.5281/zenodo.17784838](https://doi.org/10.5281/zenodo.17784838)  
**Author:** Igor Holt ([ORCID: 0009-0008-8389-1297](https://orcid.org/0009-0008-8389-1297))  
**Part 3 of LID-LIFT Technical Suite**

## Overview

MCP Tool Dissonance implements the Dissonance-Weighted Eviction (DWE) algorithm for Model Context Protocol tool management. This Podman edition provides rootless container deployment with systemd integration via Quadlet.

## Prerequisites

Before deploying MCP Tool Dissonance, ensure your system meets these requirements:

### System Requirements
- **Operating System**: Ubuntu 20.04 LTS or later (or any Linux with systemd)
- **Architecture**: x86_64 or arm64
- **Memory**: 256MB minimum (512MB recommended)
- **Disk**: 100MB free space

### Required Software

**Install Podman** (if not already installed):
```bash
# Ubuntu 22.04+
sudo apt update && sudo apt install -y podman

# Verify installation
podman --version  # Should show 4.0+
```

**Verify systemd user session** (for Quadlet deployment):
```bash
# Enable lingering for user services
loginctl enable-linger $USER

# Verify
systemctl --user status
```

### Pre-flight Checks
```bash
# 1. Podman works rootless
podman run --rm hello-world

# 2. User systemd is active
systemctl --user is-system-running

# 3. Quadlet generator exists (Podman 4.4+)
ls /usr/lib/systemd/system-generators/podman-system-generator
```

If all checks pass, proceed to Quick Start below.

---

## Quick Start

```bash
# Build the container
podman build -t mcp-dissonance:1.0.0 .

# Run with rootless Podman
podman run --rm -it \
  --security-opt no-new-privileges:true \
  --cap-drop ALL \
  mcp-dissonance:1.0.0
```

## Deployment Options

### 1. Automated Deployment

```bash
chmod +x deploy-podman.sh
./deploy-podman.sh
```

### 2. Podman Compose

```bash
podman-compose up -d
```

### 3. Systemd Integration (Quadlet)

```bash
# Install Quadlet unit
cp mcp-dissonance.container ~/.config/containers/systemd/
systemctl --user daemon-reload
systemctl --user start mcp-dissonance.service
```

## Security Features

- **Distroless Base**: Minimal attack surface with `gcr.io/distroless/static:nonroot`
- **Non-root User**: Runs as UID 65532 (nonroot)
- **Capability Drop**: All capabilities dropped via `--cap-drop ALL`
- **No New Privileges**: Prevents privilege escalation
- **Read-only Root**: Container filesystem is read-only

## DWE Algorithm

The Dissonance-Weighted Eviction algorithm calculates tool dissonance scores:

```
D(t) = Σ(frequency × recency × complexity) / coherence_factor
```

Tools with higher dissonance scores are prioritized for eviction from the context window.

## Configuration

Environment variables:

| Variable | Default | Description |
|----------|---------|-------------|
| `MCP_PORT` | 8080 | Server port |
| `MCP_LOG_LEVEL` | info | Log verbosity |
| `DWE_THRESHOLD` | 0.75 | Eviction threshold |
| `DWE_WINDOW_SIZE` | 100 | Context window size |

## Auto-Update

This container supports Podman auto-update:

```bash
podman auto-update --dry-run
```

## License

MIT License - See LICENSE file

## Citation

```bibtex
@software{holt_mcp_dissonance_2025,
  author       = {Holt, Igor},
  title        = {MCP Tool Dissonance: Dissonance-Weighted Eviction},
  year         = 2025,
  publisher    = {Zenodo},
  doi          = {10.5281/zenodo.17784838},
  url          = {https://doi.org/10.5281/zenodo.17784838}
}
```
