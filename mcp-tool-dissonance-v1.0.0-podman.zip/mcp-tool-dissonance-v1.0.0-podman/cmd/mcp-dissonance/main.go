// MCP Tool Dissonance v1.0.0 - Podman Edition
// DOI: 10.5281/zenodo.17784838
// Author: Igor Holt (ORCID: 0009-0008-8389-1297)
// Part 3 of LID-LIFT Technical Suite

package main

import (
	"context"
	"flag"
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"github.com/igorholt/mcp-tool-dissonance/internal/config"
	"github.com/igorholt/mcp-tool-dissonance/internal/server"
	"github.com/rs/zerolog/log"
)

var (
	Version = "1.0.0"
	DOI     = "10.5281/zenodo.17784838"
	ORCID   = "0009-0008-8389-1297"
)

func main() {
	showVersion := flag.Bool("version", false, "Show version")
	showHealth := flag.Bool("health", false, "Health check")
	flag.Parse()

	if *showVersion {
		fmt.Printf("MCP Tool Dissonance v%s\nDOI: %s\n", Version, DOI)
		os.Exit(0)
	}
	if *showHealth {
		fmt.Println("OK")
		os.Exit(0)
	}

	log.Info().Str("doi", DOI).Msg("Starting server")

	cfg, _ := config.Load("")
	srv, _ := server.New(cfg)

	ctx, cancel := context.WithCancel(context.Background())
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)

	go srv.Start(ctx)

	<-sigChan
	cancel()
	srv.Shutdown(ctx)
}
