#!/usr/bin/env bash
# MCP Tool Dissonance v1.0.0 - Podman Edition
# DOI: 10.5281/zenodo.17784838
# Author: Igor Holt (ORCID: 0009-0008-8389-1297)
# Part 3 of LID-LIFT Technical Suite
#
# Automated deployment script for rootless Podman

set -euo pipefail

readonly VERSION="1.0.0"
readonly IMAGE_NAME="mcp-dissonance"
readonly CONTAINER_NAME="mcp-dissonance"
readonly DOI="10.5281/zenodo.17784838"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*"
}

error() {
    log "ERROR: $*" >&2
    exit 1
}

check_podman() {
    if ! command -v podman &>/dev/null; then
        error "Podman is not installed. Please install Podman first."
    fi
    log "Podman version: $(podman --version)"
}

build_image() {
    log "Building container image..."
    podman build \
        --tag "${IMAGE_NAME}:${VERSION}" \
        --tag "${IMAGE_NAME}:latest" \
        --label "org.opencontainers.image.revision=$(git rev-parse HEAD 2>/dev/null || echo 'unknown')" \
        --label "org.opencontainers.image.created=$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
        .
    log "Image built: ${IMAGE_NAME}:${VERSION}"
}

stop_existing() {
    if podman container exists "${CONTAINER_NAME}" 2>/dev/null; then
        log "Stopping existing container..."
        podman stop "${CONTAINER_NAME}" || true
        podman rm "${CONTAINER_NAME}" || true
    fi
}

run_container() {
    log "Starting container with security hardening..."
    podman run -d \
        --name "${CONTAINER_NAME}" \
        --security-opt no-new-privileges:true \
        --cap-drop ALL \
        --read-only \
        --user 65532:65532 \
        --env "MCP_DOI=${DOI}" \
        --publish 8080:8080 \
        --label "io.containers.autoupdate=registry" \
        "${IMAGE_NAME}:${VERSION}"
    
    log "Container started: ${CONTAINER_NAME}"
    podman ps --filter "name=${CONTAINER_NAME}"
}

install_quadlet() {
    local quadlet_dir="${HOME}/.config/containers/systemd"
    mkdir -p "${quadlet_dir}"
    
    if [[ -f "mcp-dissonance.container" ]]; then
        cp mcp-dissonance.container "${quadlet_dir}/"
        log "Quadlet unit installed to ${quadlet_dir}"
        systemctl --user daemon-reload
        log "Run: systemctl --user start mcp-dissonance.service"
    fi
}

show_status() {
    log "Deployment complete!"
    log "DOI: ${DOI}"
    log "Container status:"
    podman inspect "${CONTAINER_NAME}" --format '{{.State.Status}}' 2>/dev/null || echo "Not running"
}

main() {
    log "MCP Tool Dissonance Deployment v${VERSION}"
    log "DOI: ${DOI}"
    
    check_podman
    build_image
    stop_existing
    run_container
    install_quadlet
    show_status
}

main "$@"
