// MCP Tool Dissonance v1.0.0 - Podman Edition
// DOI: 10.5281/zenodo.17784838
// Author: Igor Holt (ORCID: 0009-0008-8389-1297)
// Part 3 of LID-LIFT Technical Suite

module github.com/igorholt/mcp-tool-dissonance

go 1.21

require (
	github.com/gorilla/mux v1.8.1
	github.com/rs/zerolog v1.31.0
	golang.org/x/sync v0.5.0
)
