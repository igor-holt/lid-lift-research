// MCP Tool Dissonance v1.0.0 - Podman Edition
// DOI: 10.5281/zenodo.17784838
// Author: Igor Holt (ORCID: 0009-0008-8389-1297)
// Part 3 of LID-LIFT Technical Suite

package config

import (
	"fmt"
	"os"
	"strconv"
)

type Config struct {
	Port          int
	Host          string
	DWEThreshold  float64
	DWEWindowSize int
	LogLevel      string
	DOI           string
	ORCID         string
}

const (
	DefaultPort      = 8080
	DefaultHost      = "0.0.0.0"
	DefaultThreshold = 0.75
	DefaultWindow    = 100
	DefaultLogLevel  = "info"
)

func Load(path string) (*Config, error) {
	cfg := &Config{
		Port:          DefaultPort,
		Host:          DefaultHost,
		DWEThreshold:  DefaultThreshold,
		DWEWindowSize: DefaultWindow,
		LogLevel:      DefaultLogLevel,
		DOI:           "10.5281/zenodo.17784838",
		ORCID:         "0009-0008-8389-1297",
	}

	if p := os.Getenv("MCP_PORT"); p != "" {
		cfg.Port, _ = strconv.Atoi(p)
	}
	if h := os.Getenv("MCP_HOST"); h != "" {
		cfg.Host = h
	}
	if t := os.Getenv("DWE_THRESHOLD"); t != "" {
		cfg.DWEThreshold, _ = strconv.ParseFloat(t, 64)
	}
	if w := os.Getenv("DWE_WINDOW_SIZE"); w != "" {
		cfg.DWEWindowSize, _ = strconv.Atoi(w)
	}
	if l := os.Getenv("MCP_LOG_LEVEL"); l != "" {
		cfg.LogLevel = l
	}
	return cfg, nil
}

// String returns config as string
func (c *Config) String() string {
	return fmt.Sprintf("Config{Port:%d, Threshold:%.2f, Window:%d}", c.Port, c.DWEThreshold, c.DWEWindowSize)
}
