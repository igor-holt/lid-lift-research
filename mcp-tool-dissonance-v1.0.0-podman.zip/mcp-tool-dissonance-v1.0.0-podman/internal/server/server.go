// MCP Tool Dissonance v1.0.0 - Podman Edition
// DOI: 10.5281/zenodo.17784838
// Author: Igor Holt (ORCID: 0009-0008-8389-1297)
// Part 3 of LID-LIFT Technical Suite

package server

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/gorilla/mux"
	"github.com/igorholt/mcp-tool-dissonance/internal/config"
	"github.com/igorholt/mcp-tool-dissonance/internal/tools"
	"github.com/igorholt/mcp-tool-dissonance/pkg/mcp"
)

type Server struct {
	config     *config.Config
	router     *mux.Router
	httpServer *http.Server
	tools      *tools.Registry
	dissonance *tools.DissonanceCalculator
	eviction   *tools.EvictionEngine
}

func New(cfg *config.Config) (*Server, error) {
	s := &Server{
		config:     cfg,
		router:     mux.NewRouter(),
		tools:      tools.NewRegistry(),
		dissonance: tools.NewDissonanceCalculator(cfg.DWEThreshold),
		eviction:   tools.NewEvictionEngine(cfg.DWEWindowSize, cfg.DWEThreshold),
	}
	s.setupRoutes()
	return s, nil
}

func (s *Server) setupRoutes() {
	s.router.HandleFunc("/health", s.handleHealth).Methods(http.MethodGet)
	api := s.router.PathPrefix("/api/v1").Subrouter()
	api.HandleFunc("/tools", s.handleListTools).Methods(http.MethodGet)
	api.HandleFunc("/tools", s.handleRegisterTool).Methods(http.MethodPost)
	api.HandleFunc("/dissonance", s.handleDissonance).Methods(http.MethodPost)
	api.HandleFunc("/eviction", s.handleEviction).Methods(http.MethodPost)
}

func (s *Server) Start(ctx context.Context) error {
	s.httpServer = &http.Server{Addr: fmt.Sprintf(":%d", s.config.Port), Handler: s.router}
	go s.httpServer.ListenAndServe()
	<-ctx.Done()
	return nil
}

func (s *Server) Shutdown(ctx context.Context) error {
	return s.httpServer.Shutdown(ctx)
}

func (s *Server) handleHealth(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(map[string]string{"status": "healthy", "doi": "10.5281/zenodo.17784838"})
}

func (s *Server) handleListTools(w http.ResponseWriter, r *http.Request) {
	json.NewEncoder(w).Encode(s.tools.List())
}

func (s *Server) handleRegisterTool(w http.ResponseWriter, r *http.Request) {
	var tool mcp.Tool
	json.NewDecoder(r.Body).Decode(&tool)
	tool.RegisteredAt = time.Now()
	s.tools.Register(&tool)
	w.WriteHeader(http.StatusCreated)
}

func (s *Server) handleDissonance(w http.ResponseWriter, r *http.Request) {
	var req mcp.DissonanceRequest
	json.NewDecoder(r.Body).Decode(&req)
	json.NewEncoder(w).Encode(s.dissonance.Calculate(&req))
}

func (s *Server) handleEviction(w http.ResponseWriter, r *http.Request) {
	var req mcp.EvictionRequest
	json.NewDecoder(r.Body).Decode(&req)
	json.NewEncoder(w).Encode(s.eviction.Execute(s.tools, req.MaxEvictions))
}
