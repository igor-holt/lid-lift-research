// MCP Tool Dissonance v1.0.0 - Podman Edition
// DOI: 10.5281/zenodo.17784838
// Author: Igor Holt (ORCID: 0009-0008-8389-1297)
// Part 3 of LID-LIFT Technical Suite

package tools

import (
	"math"
	"sort"
	"sync"
	"time"

	"github.com/igorholt/mcp-tool-dissonance/pkg/mcp"
)

// DissonanceCalculator computes DWE scores for tools
type DissonanceCalculator struct {
	threshold float64
	mu        sync.RWMutex
}

func NewDissonanceCalculator(threshold float64) *DissonanceCalculator {
	return &DissonanceCalculator{threshold: threshold}
}

// Calculate computes dissonance: D(t) = (frequency × recency × complexity) / coherence
func (dc *DissonanceCalculator) Calculate(req *mcp.DissonanceRequest) *mcp.DissonanceResult {
	dc.mu.Lock()
	defer dc.mu.Unlock()

	freq := dc.frequencyComponent(req.UsageCount, req.TotalCalls)
	recency := dc.recencyComponent(req.LastUsed)
	complexity := dc.complexityComponent(req.ParameterCount, req.OutputSize)
	coherence := dc.coherenceComponent(req.ContextTools, req.ToolID)

	score := math.Min(1.0, math.Max(0.0, (freq*recency*complexity)/coherence))

	return &mcp.DissonanceResult{
		ToolID:      req.ToolID,
		Score:       score,
		ShouldEvict: score > dc.threshold,
		Components:  mcp.DissonanceComponents{Frequency: freq, Recency: recency, Complexity: complexity, Coherence: coherence},
	}
}

func (dc *DissonanceCalculator) CalculateBatch(tools []mcp.DissonanceRequest) []*mcp.DissonanceResult {
	results := make([]*mcp.DissonanceResult, len(tools))
	for i, t := range tools {
		results[i] = dc.Calculate(&t)
	}
	sort.Slice(results, func(i, j int) bool { return results[i].Score > results[j].Score })
	return results
}

func (dc *DissonanceCalculator) frequencyComponent(usage, total int) float64 {
	if total == 0 {
		return 1.0
	}
	return 1.0 - float64(usage)/float64(total)
}

func (dc *DissonanceCalculator) recencyComponent(lastUsed time.Time) float64 {
	if lastUsed.IsZero() {
		return 1.0
	}
	hours := time.Since(lastUsed).Hours()
	return math.Min(1.0, 1.0-math.Exp(-hours/24.0))
}

func (dc *DissonanceCalculator) complexityComponent(params, output int) float64 {
	return (math.Min(1.0, float64(params)/10.0) + math.Min(1.0, float64(output)/10240.0)) / 2.0
}

func (dc *DissonanceCalculator) coherenceComponent(ctx []string, id string) float64 {
	if len(ctx) == 0 {
		return 1.0
	}
	for _, c := range ctx {
		if c == id {
			return 2.0
		}
	}
	return 1.0 / (1.0 + math.Log(float64(len(ctx)+1)))
}

func (dc *DissonanceCalculator) SetThreshold(t float64) {
	dc.mu.Lock()
	dc.threshold = t
	dc.mu.Unlock()
}
