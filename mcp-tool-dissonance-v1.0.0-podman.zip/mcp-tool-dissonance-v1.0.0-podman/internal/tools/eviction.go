// MCP Tool Dissonance v1.0.0 - Podman Edition
// DOI: 10.5281/zenodo.17784838
// Author: Igor Holt (ORCID: 0009-0008-8389-1297)
// Part 3 of LID-LIFT Technical Suite

package tools

import (
	"fmt"
	"sort"
	"sync"
	"time"

	"github.com/igorholt/mcp-tool-dissonance/pkg/mcp"
)

// EvictionEngine implements the DWE algorithm for tool eviction
type EvictionEngine struct {
	windowSize int
	threshold  float64
	calculator *DissonanceCalculator
	history    []EvictionEvent
	mu         sync.RWMutex
}

// EvictionEvent records eviction for audit
type EvictionEvent struct {
	ToolID    string    `json:"tool_id"`
	Score     float64   `json:"score"`
	Reason    string    `json:"reason"`
	Timestamp time.Time `json:"timestamp"`
}

// EvictionCandidate represents a tool that may be evicted
type EvictionCandidate struct {
	Tool   *mcp.Tool `json:"tool"`
	Score  float64   `json:"score"`
	Rank   int       `json:"rank"`
	Reason string    `json:"reason"`
}

func NewEvictionEngine(windowSize int, threshold float64) *EvictionEngine {
	return &EvictionEngine{
		windowSize: windowSize,
		threshold:  threshold,
		calculator: NewDissonanceCalculator(threshold),
		history:    make([]EvictionEvent, 0),
	}
}

// Execute evicts tools with highest dissonance scores
func (ee *EvictionEngine) Execute(registry *Registry, maxEvictions int) []string {
	ee.mu.Lock()
	defer ee.mu.Unlock()

	tools := registry.List()
	type scored struct {
		tool  *mcp.Tool
		score float64
	}

	scored_tools := make([]scored, len(tools))
	for i, t := range tools {
		req := &mcp.DissonanceRequest{
			ToolID:         t.ID,
			UsageCount:     t.UsageCount,
			TotalCalls:     t.TotalCalls,
			LastUsed:       t.LastUsed,
			ParameterCount: len(t.Parameters),
			OutputSize:     t.AverageOutputSize,
		}
		result := ee.calculator.Calculate(req)
		scored_tools[i] = scored{tool: t, score: result.Score}
	}

	sort.Slice(scored_tools, func(i, j int) bool { return scored_tools[i].score > scored_tools[j].score })

	evicted := make([]string, 0)
	for _, st := range scored_tools {
		if len(evicted) >= maxEvictions {
			break
		}
		if st.score > ee.threshold {
			registry.Delete(st.tool.ID)
			evicted = append(evicted, st.tool.ID)
			ee.recordEviction(st.tool.ID, st.score, "DWE threshold exceeded")
			GlobalMetrics.RecordEviction()
		}
	}
	return evicted
}

// ExecuteContextPressure evicts when context window full
func (ee *EvictionEngine) ExecuteContextPressure(registry *Registry) []string {
	ee.mu.Lock()
	defer ee.mu.Unlock()

	tools := registry.List()
	if len(tools) <= ee.windowSize {
		return nil
	}

	toEvict := len(tools) - ee.windowSize
	type scored struct {
		tool  *mcp.Tool
		score float64
	}

	scored_tools := make([]scored, len(tools))
	for i, t := range tools {
		req := &mcp.DissonanceRequest{
			ToolID:         t.ID,
			UsageCount:     t.UsageCount,
			TotalCalls:     t.TotalCalls,
			LastUsed:       t.LastUsed,
			ParameterCount: len(t.Parameters),
		}
		scored_tools[i] = scored{tool: t, score: ee.calculator.Calculate(req).Score}
	}

	sort.Slice(scored_tools, func(i, j int) bool { return scored_tools[i].score > scored_tools[j].score })

	evicted := make([]string, 0, toEvict)
	for i := 0; i < toEvict && i < len(scored_tools); i++ {
		st := scored_tools[i]
		registry.Delete(st.tool.ID)
		evicted = append(evicted, st.tool.ID)
		ee.recordEviction(st.tool.ID, st.score, "Context pressure")
	}
	return evicted
}

func (ee *EvictionEngine) GetCandidates(tools []*mcp.Tool) []EvictionCandidate {
	candidates := make([]EvictionCandidate, 0)
	for _, t := range tools {
		req := &mcp.DissonanceRequest{
			ToolID:     t.ID,
			UsageCount: t.UsageCount,
			TotalCalls: t.TotalCalls,
			LastUsed:   t.LastUsed,
		}
		result := ee.calculator.Calculate(req)
		if result.ShouldEvict {
			candidates = append(candidates, EvictionCandidate{
				Tool:   t,
				Score:  result.Score,
				Reason: "Dissonance threshold exceeded",
			})
		}
	}
	sort.Slice(candidates, func(i, j int) bool { return candidates[i].Score > candidates[j].Score })
	for i := range candidates {
		candidates[i].Rank = i + 1
	}
	return candidates
}

func (ee *EvictionEngine) recordEviction(toolID string, score float64, reason string) {
	event := EvictionEvent{
		ToolID:    toolID,
		Score:     score,
		Reason:    reason,
		Timestamp: time.Now(),
	}
	ee.history = append(ee.history, event)
	if len(ee.history) > 1000 {
		ee.history = ee.history[len(ee.history)-1000:]
	}
}

// GetHistory returns recent eviction events
func (ee *EvictionEngine) GetHistory(limit int) []EvictionEvent {
	ee.mu.RLock()
	defer ee.mu.RUnlock()
	if limit <= 0 || limit > len(ee.history) {
		limit = len(ee.history)
	}
	start := len(ee.history) - limit
	result := make([]EvictionEvent, limit)
	copy(result, ee.history[start:])
	return result
}

// SetThreshold updates the eviction threshold
func (ee *EvictionEngine) SetThreshold(threshold float64) {
	ee.mu.Lock()
	ee.threshold = threshold
	ee.calculator.SetThreshold(threshold)
	ee.mu.Unlock()
}

// Registry manages MCP tools
type Registry struct {
	tools map[string]*mcp.Tool
	mu    sync.RWMutex
}

func NewRegistry() *Registry {
	return &Registry{tools: make(map[string]*mcp.Tool)}
}

func (r *Registry) Register(tool *mcp.Tool) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	if _, exists := r.tools[tool.ID]; exists {
		return fmt.Errorf("tool %s exists", tool.ID)
	}
	tool.RegisteredAt = time.Now()
	r.tools[tool.ID] = tool
	return nil
}

func (r *Registry) Get(id string) (*mcp.Tool, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	if t, ok := r.tools[id]; ok {
		return t, nil
	}
	return nil, fmt.Errorf("not found")
}

func (r *Registry) Delete(id string) error {
	r.mu.Lock()
	defer r.mu.Unlock()
	delete(r.tools, id)
	return nil
}

func (r *Registry) List() []*mcp.Tool {
	r.mu.RLock()
	defer r.mu.RUnlock()
	list := make([]*mcp.Tool, 0, len(r.tools))
	for _, t := range r.tools {
		list = append(list, t)
	}
	return list
}

func (r *Registry) Count() int {
	r.mu.RLock()
	defer r.mu.RUnlock()
	return len(r.tools)
}

// Clear removes all tools from registry
func (r *Registry) Clear() {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.tools = make(map[string]*mcp.Tool)
}

// Has checks if tool exists
func (r *Registry) Has(id string) bool {
	r.mu.RLock()
	defer r.mu.RUnlock()
	_, exists := r.tools[id]
	return exists
}
