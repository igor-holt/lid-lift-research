// MCP Tool Dissonance v1.0.0 - Podman Edition
// DOI: 10.5281/zenodo.17784838
// Author: Igor Holt (ORCID: 0009-0008-8389-1297)
// Part 3 of LID-LIFT Technical Suite

package tools

import (
	"sync"
	"time"
)

// Metrics tracks DWE algorithm performance
type Metrics struct {
	mu               sync.RWMutex
	CalculationCount int64
	EvictionCount    int64
	AverageScore     float64
	LastCalculation  time.Time
	CacheHits        int64
	CacheMisses      int64
	DOI              string
	ORCID            string
}

// GlobalMetrics singleton
var GlobalMetrics = &Metrics{
	DOI:   "10.5281/zenodo.17784838",
	ORCID: "0009-0008-8389-1297",
}

func (m *Metrics) RecordCalculation(score float64) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.CalculationCount++
	m.LastCalculation = time.Now()
	m.AverageScore = (m.AverageScore*float64(m.CalculationCount-1) + score) / float64(m.CalculationCount)
}

func (m *Metrics) RecordEviction() {
	m.mu.Lock()
	m.EvictionCount++
	m.mu.Unlock()
}

func (m *Metrics) RecordCacheHit() {
	m.mu.Lock()
	m.CacheHits++
	m.mu.Unlock()
}

func (m *Metrics) RecordCacheMiss() {
	m.mu.Lock()
	m.CacheMisses++
	m.mu.Unlock()
}

func (m *Metrics) GetStats() map[string]interface{} {
	m.mu.RLock()
	defer m.mu.RUnlock()
	return map[string]interface{}{
		"calculations":     m.CalculationCount,
		"evictions":        m.EvictionCount,
		"average_score":    m.AverageScore,
		"last_calculation": m.LastCalculation,
		"cache_hits":       m.CacheHits,
		"cache_misses":     m.CacheMisses,
		"doi":              m.DOI,
		"orcid":            m.ORCID,
	}
}

func (m *Metrics) CacheHitRate() float64 {
	m.mu.RLock()
	defer m.mu.RUnlock()
	total := m.CacheHits + m.CacheMisses
	if total == 0 {
		return 0.0
	}
	return float64(m.CacheHits) / float64(total)
}

func (m *Metrics) Reset() {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.CalculationCount = 0
	m.EvictionCount = 0
	m.AverageScore = 0
	m.CacheHits = 0
	m.CacheMisses = 0
}
