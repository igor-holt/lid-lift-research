// MCP Tool Dissonance v1.0.0 - Podman Edition
// DOI: 10.5281/zenodo.17784838
// Author: Igor Holt (ORCID: 0009-0008-8389-1297)
// Part 3 of LID-LIFT Technical Suite

package mcp

import "time"

type Tool struct {
	ID                string      `json:"id"`
	Name              string      `json:"name"`
	Description       string      `json:"description"`
	Parameters        []Parameter `json:"parameters"`
	Category          string      `json:"category,omitempty"`
	UsageCount        int         `json:"usage_count"`
	TotalCalls        int         `json:"total_calls"`
	LastUsed          time.Time   `json:"last_used"`
	AverageOutputSize int         `json:"average_output_size"`
	RegisteredAt      time.Time   `json:"registered_at"`
}

type Parameter struct {
	Name        string `json:"name"`
	Type        string `json:"type"`
	Description string `json:"description,omitempty"`
	Required    bool   `json:"required"`
}

type DissonanceRequest struct {
	ToolID         string    `json:"tool_id"`
	UsageCount     int       `json:"usage_count"`
	TotalCalls     int       `json:"total_calls"`
	LastUsed       time.Time `json:"last_used"`
	ParameterCount int       `json:"parameter_count"`
	OutputSize     int       `json:"output_size"`
	ContextTools   []string  `json:"context_tools,omitempty"`
}

type BatchDissonanceRequest struct {
	Tools []DissonanceRequest `json:"tools"`
}

type DissonanceResult struct {
	ToolID      string               `json:"tool_id"`
	Score       float64              `json:"score"`
	ShouldEvict bool                 `json:"should_evict"`
	Components  DissonanceComponents `json:"components"`
	Cached      bool                 `json:"cached,omitempty"`
}

type DissonanceComponents struct {
	Frequency  float64 `json:"frequency"`
	Recency    float64 `json:"recency"`
	Complexity float64 `json:"complexity"`
	Coherence  float64 `json:"coherence"`
}

type EvictionRequest struct {
	MaxEvictions int      `json:"max_evictions"`
	TargetTools  []string `json:"target_tools,omitempty"`
}

type EvictionResponse struct {
	EvictedTools []string `json:"evicted_tools"`
	Count        int      `json:"count"`
}

type MCPRequest struct {
	JSONRPC string      `json:"jsonrpc"`
	ID      interface{} `json:"id"`
	Method  string      `json:"method"`
	Params  interface{} `json:"params,omitempty"`
}

type MCPResponse struct {
	JSONRPC string      `json:"jsonrpc"`
	ID      interface{} `json:"id"`
	Result  interface{} `json:"result,omitempty"`
	Error   *MCPError   `json:"error,omitempty"`
}

type MCPError struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

const (
	ErrorCodeParseError     = -32700
	ErrorCodeInvalidRequest = -32600
	ErrorCodeMethodNotFound = -32601
	ErrorCodeInvalidParams  = -32602
	ErrorCodeInternalError  = -32603
)

func NewServerInfo() map[string]string {
	return map[string]string{
		"name":    "MCP Tool Dissonance",
		"version": "1.0.0",
		"doi":     "10.5281/zenodo.17784838",
		"orcid":   "0009-0008-8389-1297",
	}
}
